package es.velazquez.proyectointegradoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegradoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
