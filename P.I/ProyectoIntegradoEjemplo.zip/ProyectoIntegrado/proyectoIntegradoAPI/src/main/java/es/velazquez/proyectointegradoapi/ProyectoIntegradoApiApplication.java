package es.velazquez.proyectointegradoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegradoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegradoApiApplication.class, args);
	}

}
