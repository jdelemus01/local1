export interface Jwt {
  token: string
}
