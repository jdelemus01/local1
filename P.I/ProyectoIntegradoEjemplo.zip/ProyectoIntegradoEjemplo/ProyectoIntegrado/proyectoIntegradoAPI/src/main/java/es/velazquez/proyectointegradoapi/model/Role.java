package es.velazquez.proyectointegradoapi.model;

public enum Role {
    ROLE_OFF, ROLE_CUS
}
