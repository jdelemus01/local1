export const environment = {
  API_URL_PRO: "http://localhost:8080/proyectoIntegradoAPI",
  API_URL: "http://localhost:8080" //Usaremos esta para el empaquetado del backend en JAR
};
