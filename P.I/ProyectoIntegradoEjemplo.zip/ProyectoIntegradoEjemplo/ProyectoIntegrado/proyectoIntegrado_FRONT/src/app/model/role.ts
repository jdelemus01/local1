export enum Role {
  ROLE_OFF = "ROLE_OFF",
  ROLE_CUS = "ROLE_CUS"
}
