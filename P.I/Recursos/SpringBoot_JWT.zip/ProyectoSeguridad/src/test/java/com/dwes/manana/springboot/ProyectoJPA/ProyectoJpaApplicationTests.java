package com.dwes.manana.springboot.ProyectoJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
